<?php
Class Urlbuilder_model extends MY_Model
{
    var $table = 'url_builder';
}