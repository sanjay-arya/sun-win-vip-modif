<?php
Class Actionadmin_model extends MY_Model
{
    var $table = 'action_admin';
}