<?php
$lang['support_info']								= 'Quản lý hỗ trợ';

$lang['select_group_support']                       = 'Select nhóm hỗ trợ';
$lang['group_support']                              = 'Group hỗ trợ';
$lang['yahoo_image']                                = 'Kiểu hiển thị yahoo';

$lang['yahoo']                                      = 'Yahoo';
$lang['skype']                                      = 'Skype';

$lang['notice_value_error']							= '%s phải là số dương';
$lang['notice_are_you_sure_want_to_delete']			= 'Bạn có chắc chắn muốn xóa hỗ trợ';

?>