<div class="titleArea">
    <div class="wrapper">
        <div class="pageTitle">
            <h5>Manage lucky wheel</h5>
        </div>
        <div class="horControlB menu_action">
            <ul>
                <li><a href="<?php echo admin_url('event/addrotate')?>">
                        <img src="<?php echo public_url('admin')?>/images/icons/control/16/add.png">
                        <span>More free spins</span>
                    </a></li>
                <li><a href="<?php echo admin_url('event')?>">
                        <img src="<?php echo public_url('admin')?>/images/icons/control/16/list.png">
                        <span>List</span>
                    </a></li>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
</div>