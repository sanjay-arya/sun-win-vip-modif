<div class="home-view">
    <div class="text-center text-danger">
        <h3>
            You do not have access
        </h3>
    </div>
</div>