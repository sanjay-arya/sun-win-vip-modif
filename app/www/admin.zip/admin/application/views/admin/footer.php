
<div id="footer">
		<div class="wrapper">
		
		<p>License &copy; 2016 GamePortal
		</p>
		 
		</div>
		
</div>