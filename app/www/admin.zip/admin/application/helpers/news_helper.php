<?php
//function news_url($url = '')
//{
//    return base_url('news/'.$url);
//}