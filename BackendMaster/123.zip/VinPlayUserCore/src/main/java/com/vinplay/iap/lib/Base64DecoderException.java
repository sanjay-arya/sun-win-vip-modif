/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.iap.lib;

public class Base64DecoderException
extends Exception {
    private static final long serialVersionUID = 1L;

    public Base64DecoderException() {
    }

    public Base64DecoderException(String s) {
        super(s);
    }
}

