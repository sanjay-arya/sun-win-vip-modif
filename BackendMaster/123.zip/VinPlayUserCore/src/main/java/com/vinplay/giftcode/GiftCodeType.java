package com.vinplay.giftcode;

public class GiftCodeType {

    public static final int ONE_FOR_THIS_USER = 0;   // chi su dung cho user do thoi
    public static final int ONE_FOR_ONE_USER = 1;     // user nao cung co the dung
    public static final int ONE_FOR_MANY_USER = 2;      // su dung cho tat ca user, phai xac thuc sdt
    public static final int ONE_FOR_ONE_USER_IN_EVENT = 3;
}
