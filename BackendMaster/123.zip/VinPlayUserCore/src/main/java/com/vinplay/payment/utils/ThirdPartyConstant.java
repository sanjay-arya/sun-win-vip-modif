package com.vinplay.payment.utils;

public interface ThirdPartyConstant {
	interface IBC {
		String LOGIN = "LoginIbc2";
		String CHECK_BALANCE = "CheckBalanceIbc2";
		String FUN_TRANSFER = "FundTransferIbc2";
	}
}
