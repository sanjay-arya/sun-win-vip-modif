/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dichvuthe.client;

import java.util.Date;

public class DvtAlert {
    public static int disconnectRecharge = 0;
    public static int disconnectCashout = 0;
    public static int disconnectTopup = 0;
    public static Date alertDisconnectRechargeTime = new Date();
    public static Date alertDisconnectCashoutTime = new Date();
    public static Date alertDisconnectTopupTime = new Date();
    public static int timeoutRecharge = 0;
    public static int timeoutCashout = 0;
    public static int timeoutTopup = 0;
    public static Date alertTimeoutRechargeTime = new Date();
    public static Date alertTimeoutCashoutTime = new Date();
    public static Date alertTimeoutTopupTime = new Date();
    public static int viettelPending = 0;
    public static int mobiPending = 0;
    public static int vinaPending = 0;
    public static int gatePending = 0;
    public static int vcoinPending = 0;
    public static Date alertViettelPendingTime = new Date();
    public static Date alertMobiPendingTime = new Date();
    public static Date alertVinaPendingTime = new Date();
    public static Date alertGatePendingTime = new Date();
    public static Date alertVcoinPendingTime = new Date();
}

