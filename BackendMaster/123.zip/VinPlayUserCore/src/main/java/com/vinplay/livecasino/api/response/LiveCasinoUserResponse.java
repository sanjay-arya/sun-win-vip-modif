package com.vinplay.livecasino.api.response;

public class LiveCasinoUserResponse {

    public String userName;
    public String passWord;

    public LiveCasinoUserResponse(String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }
}
