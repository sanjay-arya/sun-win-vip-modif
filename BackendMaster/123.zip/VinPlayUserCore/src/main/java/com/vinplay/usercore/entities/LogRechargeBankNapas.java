/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.entities;

public class LogRechargeBankNapas {
    public String nickname;
    public long money;
    public String bank;
    public String transId;
    public String ticketNo;
    public String transTime;
    public String responseCode;
    public String description;
    public String transactionNo;
    public String updateTime;
}

