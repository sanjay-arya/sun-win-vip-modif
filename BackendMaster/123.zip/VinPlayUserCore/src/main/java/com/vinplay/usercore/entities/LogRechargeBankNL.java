/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.entities;

public class LogRechargeBankNL {
    public String nickname;
    public String email;
    public String mobile;
    public String ip;
    public String orderCode;
    public int totalAmount;
    public String bank;
    public String token;
    public String transTime;
    public String errorCodeReturn;
    public String descReturn;
    public String updateTime;
}

