/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.entities;

public class LogSmsOtp {
    public String requestId;
    public String mobile;
    public String commandCode;
    public String messageMO;
    public String responseMO;
    public String messageMT;
    public String responseMT;
    public String transTime;
}

