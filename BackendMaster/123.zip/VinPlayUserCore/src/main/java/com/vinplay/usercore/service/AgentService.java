/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.service;

public interface AgentService {
}

