package com.vinplay.dailyQuest;

public class DailyQuestDescription {
    public int type;
    public byte action;

    public DailyQuestDescription(byte action){
        this.type = 9;
        this.action = action;
    }
}
