/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.dao;

import java.sql.SQLException;

public interface GameBaiDao {
    public String getString(String var1) throws SQLException;

    public boolean saveString(String var1, String var2) throws SQLException;
}

