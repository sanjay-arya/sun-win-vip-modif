package com.vinplay.dichvuthe.service;

public interface CashOutService {
//	public void cashOutByBank(String var1, int var2);
}
