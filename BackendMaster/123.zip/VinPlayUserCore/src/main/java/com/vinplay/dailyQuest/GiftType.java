package com.vinplay.dailyQuest;

public class GiftType {
    public static final int MONEY = 0;
    public static final int FREE_SPIN = 1;
}
