package com.vinplay.dailyQuest;

public class DailyQuestDescriptionAction {

    public static final byte ACTION_NAP_THE = 0;
    public static final byte ACTION_TAI_XIU = 1;
    public static final byte ACTION_BAU_CUA = 2;
}
