package com.vinplay.dailyQuest;

public class GiftTypeData {
    public int gameID;
    public int moneyBet;

    public GiftTypeData(int gameID, int moneyBet){
        this.gameID = gameID;
        this.moneyBet = moneyBet;
    }
}
