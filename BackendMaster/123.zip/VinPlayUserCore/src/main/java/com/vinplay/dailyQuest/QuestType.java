package com.vinplay.dailyQuest;

public class QuestType {
    public static final int MONEY = 0;          // nap tien
    public static final int LINE_SLOT = 1;      // dong choi slot
    public static final int BOARD_PLAY = 2;     // cac game con lai choi mat tien
    public static final int CARD_GAME_PLAY = 3;     // So van choi game bai
}
