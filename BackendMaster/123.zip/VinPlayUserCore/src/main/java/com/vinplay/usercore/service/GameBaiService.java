/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.service;

import java.sql.SQLException;

public interface GameBaiService {
    public String getString(String var1) throws SQLException;

    public boolean saveString(String var1, String var2) throws SQLException;
}

