/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.usercore.service;

import java.sql.SQLException;

public interface BlockUserService {
    public String listBlockUser(String var1, String var2, String var3) throws SQLException;
}

