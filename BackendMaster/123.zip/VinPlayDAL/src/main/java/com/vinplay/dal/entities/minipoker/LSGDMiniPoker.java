/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.minipoker;

public class LSGDMiniPoker {
    public String username;
    public long betValue;
    public long prize;
    public String cards;
    public String timestamp;
}

