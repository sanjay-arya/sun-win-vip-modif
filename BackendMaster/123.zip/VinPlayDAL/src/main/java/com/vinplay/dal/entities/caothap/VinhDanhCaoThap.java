/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.caothap;

public class VinhDanhCaoThap {
    public String nickname;
    public long betValue;
    public long prize;
    public int result;
    public String timestamp;
}

