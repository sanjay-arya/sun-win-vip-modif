/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.report;

public class VinInModel {
    public long rechargeCard;
    public long rechargeVinCard;
    public long rechargeBank;
    public long rechargeIAP;
    public long rechargeSMS;
    public long vqmm;
    public long vqVIP;
    public long giftCode;
    public long giftCodeMKT;
    public long giftCodeVH;
    public long cashoutVippoint;
    public long refundFee;
    public long eventVP;
    public long bonusTopDS;
    public long khoBauVqFree;
    public long nuDiepVienVqFree;
    public long sieuAnhHungVqFree;
    public long vuongQuocVinVqFree;
}

