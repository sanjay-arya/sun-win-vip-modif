/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.report;

import com.vinplay.dal.entities.report.ReportMoneySystemModel;
import java.util.Map;

public class ReportUserMoneyModel {
    public String nickName;
    public long rechardMoney;
    public Map<String, ReportMoneySystemModel> actionGame;
    public Map<String, Long> actionOther;
}

