/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.caothap;

public class LSGDCaoThap {
    public long transId;
    public int potBet;
    public int step;
    public long betValue;
    public long prize;
    public String cards;
    public String timestamp;
}

