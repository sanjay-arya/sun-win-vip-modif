/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.report;

public class InititalModel {
    public long superAgent;
    public long bot;
    public long total;
}

