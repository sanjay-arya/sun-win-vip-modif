/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.caothap;

public class TopCaoThap {
    public int stt;
    public String nickname;
    public String hand;
    public long money;
    public String timestamp;
    public String prize;
}

