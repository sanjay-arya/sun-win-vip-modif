/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.service;

public interface BroadcastMessageService {
    public void putMessage(int var1, String var2, long var3);

    public String toJson();

    public void clearMessage();
}

