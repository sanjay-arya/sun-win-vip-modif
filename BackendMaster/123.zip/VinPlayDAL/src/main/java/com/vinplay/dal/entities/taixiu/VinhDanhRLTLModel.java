/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.taixiu;

public class VinhDanhRLTLModel {
    public String username;
    public long money;
    public String time;
}

