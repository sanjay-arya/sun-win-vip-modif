/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.taixiu;

public class TopTaiXiu {
    public String username;
    public long money;

    public TopTaiXiu(String username, long money) {
        this.username = username;
        this.money = money;
    }

    public TopTaiXiu() {
    }
}

