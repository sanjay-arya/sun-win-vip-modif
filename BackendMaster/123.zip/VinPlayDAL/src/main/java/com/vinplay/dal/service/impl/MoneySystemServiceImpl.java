/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.service.impl;

import com.vinplay.dal.service.MoneySystemService;

public class MoneySystemServiceImpl
implements MoneySystemService {
}

