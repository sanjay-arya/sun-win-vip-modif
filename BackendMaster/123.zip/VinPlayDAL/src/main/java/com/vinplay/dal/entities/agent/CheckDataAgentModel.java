package com.vinplay.dal.entities.agent;

import java.io.Serializable;
import java.util.Date;

public class CheckDataAgentModel {
    public int id = -1;
    public int dai_ly= -1;
    public int is_bot= -1;
}
