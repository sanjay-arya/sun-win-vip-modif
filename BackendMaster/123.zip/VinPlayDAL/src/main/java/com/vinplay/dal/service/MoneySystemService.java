/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.service;

public interface MoneySystemService {
}

