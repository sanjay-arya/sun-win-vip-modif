/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.service;

public interface LogPortalService {
    public void log(String var1);

    public void saveLog();
}

