package com.vinplay.dal.config;

public class CacheConfig {
    public static final String CACHE_USER_WIN = "usersSetWin";
    public static final String CACHE_USER_JACKPOT = "cacheSetUserJackpot";
}
