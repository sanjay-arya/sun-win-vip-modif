/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.service;

public interface ChatLobbyService {
    public void banChatUser(String var1, long var2);

    public long getBanTime(String var1);
}

