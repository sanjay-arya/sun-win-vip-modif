package com.vinplay.dal.config;

public class TypeNotifyConfig {
    public static final byte JACKPOT = 0;
    public static final byte BIG_WIN = 1;
    public static final long THRESS_HOLD = 20000000;
}
