/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.minipoker;

public class VinhDanhMiniPoker {
    public String username;
    public long betValue;
    public long prize;
    public int result;
    public String timestamp;
}

