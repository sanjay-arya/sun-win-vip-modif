/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.report;

public class ReportMoneySystemModelNew {
    public long moneyWin = 0L;
    public long moneyLost = 0L;
    public long moneyOther = 0L;
    public long fee = 0L;
    public long revenuePlayGame = 0L;
    public long revenue = 0L;
    public String dateReset;
    public String actionName;
}

