/*
 * Decompiled with CFR 0.144.
 */
package com.vinplay.dal.entities.report;

public class VinOutModel {
    public long cashOutCard;
    public long cashOutTopup;
    public long vin2xu;
    public long chargeSMS;
    public long transferMoney;
    public long gcAgent;
}

