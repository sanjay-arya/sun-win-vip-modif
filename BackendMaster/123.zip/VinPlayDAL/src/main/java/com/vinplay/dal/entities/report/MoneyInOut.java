package com.vinplay.dal.entities.report;

public class MoneyInOut {
    public long total;
    public long fee;
    public String actionName;
}
